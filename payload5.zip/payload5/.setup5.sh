c='\033[1;36m'
g='\033[1;32m'
p='\033[1;35m'
cd
clear
rm -rf $HOME/payload5.zip
rm -rf $HOME/payload5
rm -rf $HOME/../usr/bin/payload.sh
rm -rf $HOME/../usr/bin/payload
rm -rf $HOME/../usr/bin/setup5.sh
clear
echo -e "$c ali.max = $g https://www.facebook.com/ali.max.796774  "
echo -e "$g"
read -p "               -------(entar)------"
clear
echo -e $g 'Please Wait ===+['$p'>              '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'->             '$g']|'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-->            '$g']/'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'--->           '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'---->          '$g']|'
pkg install git -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'----->         '$g']/'
pkg install figlet -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']|'
pkg install python -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']\'
pkg install python2 -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']/'
pkg install python3 -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------->       '$g']|'
pkg install nano -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'-------->      '$g']/'
pkg install curl -y > nn.txt
rm nn.txt
clear

echo -e $g 'Please Wait ===+['$p'--------->     '$g']\'
sleep 0.6
clear
echo -e $g 'Please Wait ===+['$p'---------->    '$g']|'
sleep 0.5
clear
echo -e $g 'Please Wait ===+['$p'----------->   '$g']/'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-------------> '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-------------->'$g']|'
sleep 0.4
clear




echo -e "$g+++++++++++++++>$p[Please Wait]$g<++++++++++++++"

mkdir /sdcard/payload5
mkdir /sdcard/payload5/Encrypt
clear
echo -e "$g+++++++++++++++>$p[Please Wait]$g<++++++++++++++"
git clone https://github.com/payload5/payload5

cp payload5/payload5.zip $HOME

rm -rf payload5

unzip payload5.zip

cd payload5 && chmod +x *
cd
cp $HOME/payload5/payload.sh $HOME/../usr/bin/payload.sh
cp $HOME/payload5/payload.sh $HOME/../usr/bin/payload
cp $HOME/payload5/.setup5.sh $HOME/../usr/bin/setup5.sh
chmod +x $HOME/../usr/bin/setup5.sh
cd
rm -rf setupp
clear

echo -e "$g+++++++++++>[$pWelcome to the new update$p$g]<+++++++++++++"
echo -e "     Hello      "
echo -e "     $p     new "
echo -e "     $g         Update "
sleep 2
payload
