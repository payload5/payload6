cd $HOME/payload5/.max
chmod +x .mkm.php
php .mkm.php
