g='\033[1;32m'
echo $g
clear
echo " ip = 100006"
echo " password ="
sleep 0.3
clear
echo " ip = 10000654123"
echo " password ="
sleep 0.3
clear
echo " ip = 100006541234"
echo " password ="
sleep 0.3
clear
echo " ip = 1000065412345"
echo " password ="
sleep 0.3
clear
echo " ip = 10000654123456"
echo " password ="
sleep 0.3
clear
echo " ip = 10000654123456"
echo " password = pas"
sleep 0.3
clear
echo " ip = 10000654123456"
echo " password = passw"
sleep 0.3
clear
echo " ip = 10000654123456"
echo " password = passwor"
sleep 0.3
clear
echo " ip = 10000654123456"
echo " password = password"
sleep 0.3
clear
echo " ip = 10000654123456"
echo " password = password.t"
sleep 0.3
clear
echo " ip = 10000654123456"
echo " password = password.txt"
sleep 1

