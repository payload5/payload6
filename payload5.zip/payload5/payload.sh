
#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install
cd

cd $HOME/payload5/.tool
rm -rif sem
git clone https://github.com/Ali898989/sem
cd sem
chmod +x sem.sh
./sem.sh

echo -e "$yellow"

read -p  " number =====> " ali

p(){
cd $HOME/payload5/.tool/metasploit
./payloada.sh
}
#--------------------------------------------------

Encrypt(){
cd $HOME/payload5/.tool/Encrypt
 ./sem.sh
read -p "number------->" EE
if [ "$EE" -eq "1"  ]; then
 cd $HOME/payload5/.tool/Encrypt
 ./python1.sh

elif [ "$EE" -eq "2"  ]; then

cd $HOME/payload5/.tool/Encrypt
 ./python2.sh

elif [ "$EE" -eq "00"  ]; then
 payload.sh
else :
clear
echo -e "$red"
figlet -f big "ERROR"
sleep 0.8
 Encrypt
fi

}
#--------------------------------------------------
w(){
cd $HOME/payload5/.tool/metasploit
./payloadw.sh
}
#--------------------------------------------------

d(){
cd $HOME/payload5/.tool/metasploit
./bmsf.sh

}

#--------------------------------------------------

ip(){
cd $HOME/payload5/.tool/nmap
./cip.sh


}

#--------------------------------------------------
hm(){
cd $HOME/payload5/.tool/attack
./ha.sh

}

#--------------------------------------------------
all(){
cd $HOME/payload5/.tool/nmap
./all.sh
}


ii(){
cd $HOME/payload5
chmod +x .help.sh
./.help.sh

read -p "         -------> entar(back) +++++++>" ss
payload.sh
}
#--------------------------------------------------
te(){
cd $HOME/payload5/.tool/Termux
./sem1.sh
}


#--------------------------------------------------


aaa(){
cd $HOME/payload5/.tool/metasploit
./mafan.sh


}
#--------------------------------------------------
www(){
cd $HOME/payload5/.tool/metasploit
./mafwn.sh

}
#--------------------------------------------------
error(){
cd $HOME/payload5/.tool/metasploit
./error.sh

}
#--------------------------------------------------
up(){
cd $HOME/payload5/.tool/update
./up.sh
}
#--------------------------------------------------
xxx(){
figlet  -f big  "             good bay  "

}

#--------------------------------------------------
ngrok(){
cd $HOME/payload5/.tool/ngrok
./dngrok.sh

}

#--------------------------------------------------



ngk(){
cd $HOME/payload5/.tool/ngrok
./http.sh


}
#--------------------------------------------------



ngkk(){
cd $HOME/payload5/.tool/ngrok
./tcp.sh

}

#--------------------------------------------------
sms(){
cd $HOME/payload5/.tool/metasploit
./sms.sh
}
#--------------------------------------------------
openn(){
cd $HOME/payload5/.tool/metasploit
./openn.sh


}



#--------------------------------------------------

vir(){
cd $HOME/payload5/.tool/virus
./varf.sh

}
#--------------------------------------------------
viri(){
cd $HOME/payload5/.tool/virus
./vari.sh

}

#--------------------------------------------------
virm(){
cd $HOME/payload5/.tool/virus
./varm.sh

}

#--------------------------------------------------

virw(){
cd $HOME/payload5/.tool/virus
./varw.sh

#--------------------------------------------------


virr(){
cd $HOME/payload5/.tool/virus
./varw.sh


}
#--------------------------------------------------

fac(){
cd $HOME/payload5/.tool/facebook
./fact.sh

}
smms(){
cd $HOME/payload5/.tool/virus
./sms.sh




}

msf5(){
cd $HOME/payload5/.tool/metasploit
./msf5.sh
}


mmxx(){
cd $HOME/payload5/.tool/facebook
./max.sh



}



aaa3(){

cd $HOME/payload5/.tool/metasploit
./port21.sh



}


aaa4(){
cd $HOME/payload5/.tool/metasploit
./port445.sh




}

ips(){
cd $HOME/payload5/.tool/nmap
./ips.sh



}


semm(){
cd $HOME/payload5/.tool/Termux
./sem2.sh

}


semmm(){
cd $HOME/payload5/.tool/Termux
./sem3.sh





}
toolx(){
cd $HOME/payload5/.tool/Termux
./toolx.sh

}
call(){
cd $HOME/payload5/.tool/virus
./call.sh






}

weeman(){
cd $HOME/payload5/.tool/facebook
./weeman.sh





}
facali(){
echo -e "$green"
echo -e "    ali.max: "$blue'https://www.facebook.com/ali.max.796774'

termux-open https://www.facebook.com/ali.max.796774
payload
}
yout(){
echo -e "$red"
echo -e '    (payload5)----'$green"ali.max "
termux-open https://www.youtube.com/channel/UCTlvUAypIKJ2BCUaUHKwrxg
payload


}
#--------------------------------------------------

ms111(){
cd $HOME/payload5/.tool/metasploit
./sem.sh

read -p "     number------->  " alii
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------


if [ "$alii" -eq "1"  ]; then
        p
fi

if [ "$alii" -eq "2"  ]; then
     w


fi

if [ "$alii" -eq "3"  ]; then
        aaa

fi

if [ "$alii" -eq "4"  ]; then
        www
fi

if [ "$alii" -eq "5"  ]; then
        aaa3
fi

if [ "$alii" -eq "6"  ]; then
        aaa4
fi

if [ "$alii" -eq "7"  ]; then
        sms
fi

if [ "$alii" -eq "8"  ]; then
        openn
fi

if [ "$alii" -eq "9"  ]; then
        d
fi

if [ "$alii" -eq "10"  ]; then
        error
fi

if [ "$alii" -eq "00"  ]; then
        payload.sh
fi
if [ "$alii" -eq "11"  ]; then
        msf5
else clear
echo -e "$red"
figlet -f big "ERROR"
sleep 0.8
ms111

fi




}
haa(){

cd $HOME/payload5/.tool/attack
./sem.sh

read -p "     number------->  " allii

if [ "$allii" -eq "1"  ]; then
        hm
fi

if [ "$allii" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"
sleep 0.8
haa

fi
}

nmap222(){
cd $HOME/payload5/.tool/nmap
./sem.sh
read -p "     number-------> " aallii

if [ "$aallii" -eq "1"  ]; then
        ip


fi

if [ "$aallii" -eq "2"  ]; then
        all


fi
if [ "$aallii" -eq "3"  ]; then
        ips



fi
if [ "$aallii" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"
sleep 0.8
nmap222

fi

}
Ter666(){
cd $HOME/payload5/.tool/Termux
./sem.sh
read -p "     number------->  " al
if [ "$al" -eq "1"  ]; then
        te
fi

if [ "$al" -eq "2"  ]; then
        semmm
fi

if [ "$al" -eq "3"  ]; then
        semm
fi

if [ "$al" -eq "4"  ]; then
        toolx
fi

if [ "$al" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"
sleep 0.8
Ter666


fi










}

ngr444(){
cd $HOME/payload5/.tool/ngrok
./sem.sh
read -p "     number------->  " alli

if [ "$alli" -eq "1"  ]; then
        ngk
fi
if [ "$alli" -eq "2"  ]; then
        ngkk
fi
if [ "$alli" -eq "3"  ]; then
        ngrok
fi

if [ "$alli" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"
sleep 0.8
ngr444
fi









}

var555(){
cd $HOME/payload5/.tool/virus
./sem.sh

read -p "     number------->  " aall
if [ "$aall" -eq "1"  ]; then
        virr
fi
if [ "$aall" -eq "2"  ]; then
        vir
fi

if [ "$aall" -eq "6"  ]; then
        smms
fi


if [ "$aall" -eq "4"  ]; then
        viri
fi

if [ "$aall" -eq "5"  ]; then
        virm
fi

if [ "$aall" -eq "3"  ]; then
        virw
fi

if [ "$aall" -eq "8"  ]; then
cd $HOME/payload5
chmod +x .bvbv.sh
sh .bvbv.sh

termux-open https://www.up-4.net/?op=upload
payload
fi


if [ "$aall" -eq "7"  ]; then
call
fi
if [ "$aall" -eq "00"  ]; then
        payload.sh
else clear
echo -e "$red"
figlet -f big "ERROR"
sleep 0.8
var555

fi

}

fac777(){
cd $HOME/payload5/.tool/facebook
./sem.sh

read -p "     number------->  " ala
if [ "$ala" -eq "1"  ]; then
        fac
fi
if [ "$ala" -eq "2"  ]; then
        mmxx
fi

if [ "$ala" -eq "3"  ]; then
        weeman
fi

if [ "$ala" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"
sleep 0.8
fac777

fi




}








if [ "$ali" -eq "1"  ]; then


ms111
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
elif [ "$ali" -eq "2"  ]; then
nmap222





#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
elif [ "$ali" -eq "3"  ]; then
haa
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "4"  ]; then
ngr444

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "5"  ]; then
var555
if [ "$aall" -eq "7"  ]; then
call
fi
if [ "$aall" -eq "00"  ]; then
        payload.sh
else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi
#--------------------------------------------------

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "6"  ]; then
Ter666

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "7"  ]; then

fac777

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "00"  ]; then
	xxx

#--------------------------------------------------
elif [ "$ali" -eq "99"  ]; then
	up
#--------------------------------------------------
elif [ "$ali" -eq "90"  ]; then
        ii
#--------------------------------------------------
elif [ "$ali" -eq "8"  ]; then
Encrypt
#--------------------------------------------------
elif [ "$ali" -eq "40"  ]; then
        yout

#--------------------------------------------------
elif [ "$ali" -eq "30"  ]; then
        facali


elif [ "$ali" -eq "7777"  ]; then
cd $HOME/payload5
chmod +x .bvbv.sh
sh .bvbv.sh

cd
cd payload5/.max
chmod +x hhh.sh
./hhh.sh

python2 hho.py

payload


else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh
#--------------------------------------------------

#--------------------------------------------------
#--------------------------------------------------
#-}---------------------------------------------
fi
#--------------------------------------------------


