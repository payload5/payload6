cd
python2 $HOME/payload5/.max/zz.py
