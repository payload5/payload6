rm -rf $HOME/metasploit-framework
rm -rf $HOME/metasploit.sh
cp .metasploit.sh $HOME/metasploit.sh
chmod +x $HOME/metasploit.sh
sh $HOME/metasploit.sh
