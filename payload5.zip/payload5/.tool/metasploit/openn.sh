#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install




echo -e "$red"
echo "                                 [0]back"
echo -e "$green    "
cd $HOME/payload5/.msf && ls
echo ""
read -p "name photo ------> " n
echo -e "$green"
if [ "$n" -eq "0"  ]; then
cd $HOME/payload5
payload.sh
else
termux-open $n
echo "                                   good pay"
fi
