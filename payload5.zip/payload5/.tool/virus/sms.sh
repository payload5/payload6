#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'






clear
cd
cd payload5
cd .Spammer-Grab

chmod +x auto-install.sh spammer.py
echo -e "$yellow"
read -p "       Enter the number ----> " f
echo -e "$green"
sleep 0.3
echo "                            ===+ $f send++"
sleep 0.3
echo "                               =========+ $f send++"
sleep 0.3
echo "                                   ==============+ $f send++"
cd $HOME/payload5
chmod +x .fhon.sh
./.fhon.sh
./.fhon.sh
./.fhon.sh
./.fhon.sh
cd .Spammer-Grab
./auto-install.sh
python2 spammer.py --delay 30 $f
cd ..
payload.sh
