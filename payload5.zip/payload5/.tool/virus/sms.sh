#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'






clear
cd
cd payload5
cd .Spammer-Grab

chmod +x auto-install.sh spammer.py
echo -e "$yellow"
read -p "       Enter the number ----> " f
if [ "$f" -eq "201113925818"  ]; then
 echo "           a7a"
elif [ "$f" -eq "201114605945"  ]; then
 echo "           a7a"
elif [ "$f" -eq "201145586677"  ]; then
 echo "           a7a"
elif [ "$f" -eq "201121201347"  ]; then
 echo "           a7a"
elif [ "$f" -eq "201121201348"  ]; then
 echo "           a7a"
elif [ "$f" -eq "201156595191"  ]; then
 echo "           a7a"
elif [ "$f" -eq "201112134842"  ]; then
 echo "           a7a"
elif [ "$f" -eq "201228232755"  ]; then
 echo "           a7a"
elif [ "$f" -eq "201029441199"  ]; then
 echo "           a7a"


else




echo -e "$green"
sleep 0.3
echo "                            ===+ $f send++"
sleep 0.3
echo "                               =========+ $f send++"
sleep 0.3
echo "                                   ==============+ $f send++"
cd $HOME/payload5
chmod +x .fhon.sh
./.fhon.sh
./.fhon.sh
./.fhon.sh
./.fhon.sh
cd .Spammer-Grab
./auto-install.sh
python2 spammer.py --delay 30 $f
cd ..
payload.sh
fi
