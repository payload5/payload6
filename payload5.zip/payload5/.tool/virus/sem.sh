#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'





echo -e "     $yellow                                     [00]back"
echo -e "$red"
echo "          [1]Create a normal (virus)☢️"
echo "          [2]Create a semi-Facebook (virus)️️️☢️"
echo "          [3]Create a semi-WhatsApp (virus)️️️☢️"
echo "          [4]Create a semi-Instagram (virus)️️️☢️"
echo "          [5]Create a semi-Messenger (virus)️️️☢️"
echo "          [6]send sms to  ********* 📩"
echo "          [7]send call to ********* 📞 "
echo "          [8]Upload (virus) and (payload)⬆️ "
echo -e "$green"
