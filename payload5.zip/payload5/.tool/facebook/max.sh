clear
cd
pip2 install mechanize
cd $HOME/payload5/.max
clear
python2 op.py
