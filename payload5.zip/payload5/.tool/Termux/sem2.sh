read -p "            name-------> " ali
cd
rm $HOME/.bashrc
rm ../usr/etc/bash.bashrc
sed "s/max/$ali/" $HOME/payload5/.max/PROVE-TM > $HOME/.bashrc
pkg install figlet

payload.sh
