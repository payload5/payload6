read -p "            name-------> " ali
cd
rm $HOME/.bashrc
rm ../usr/etc/bash.bashrc
sed "s/Sniper/$ali/" $HOME/payload5/.bashrc > $HOME/.bashrc
pkg install figlet

payload
