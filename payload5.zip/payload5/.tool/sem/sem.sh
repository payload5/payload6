clear

#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install




cd $HOME/payload5


echo -e "$green "

figlet  -f big "           payload 5  "
echo -e "$blue"
echo '        .e$$$$e.'
sleep 0.1
echo '      e$$$$$$$$$$e'"                        &&&&&&&&&&&&&"
sleep 0.1
echo -e '     $$$$$$$$$$$$$$'"                       & $green ali.max $blue &"
sleep 0.1
echo '    d$$$$$$$$$$$$$$b'"                      &&&&&&&&&&&&&"
echo '    $$$$$$$$$$$$$$$$                    '
sleep 0.1
echo -e '   4$$$$$$$$$$$$$$$$F'$y '                    ['$cyan "30" $y']' $blue"facebook"
sleep 0.1
echo -e '   4$$$$$$$$$$$$$$$$F'$y '                    ['$cyan "40" $y']'$red" YouTube"$blue
sleep 0.1
echo -e '    $$$" "$$$$" "$$$'"$g     6.0.0     ""$blue"
echo  '    $$F   4$$F   4$$===============||'
sleep 0.1
echo -e '     $F '$green"&" $blue'4$$F '$green"&"$blue  '4$                ||       '
echo '     $$   $$$$   $$                ||      '
sleep 0.1
echo '     $$$$$$""$$$$$$                ||     '
echo -e '      $$$F'$green "o"$blue '4$$$$                 || '
sleep 0.1
echo '       "$$$ee$$$"                  ||'
echo '        4*$$$$F4                \  ||  /'
sleep 0.1
echo -e '        $ '$green"----"$blue'.$                 \ || /'
echo -e '        "$$$$$$"   '$cyan'  [90]helpℹ️ '$blue'   \||/   '
echo '          $$$$                     \/       '
sleep 0.1
echo -e "               $bluo p $green a $reset y $purple l $cyan o $yellow a $green d"
#echo -e "$red"
#echo '                               exit=CTRL+c'
echo -e "$green+________________________________________________________+"
echo -e "$cyan|  [1] metasploit ⚔️|  $blue  [2] nmap 🌎| $purple  [3] dos attack ⛔ |             "
#echo -e "| $green            --------------------------------            |  "
echo -e "$yellow|  [4]   ngrok 🌐  |  $red  [5] virus ☢️️|  $reset [6]   Termux 📟   |    "
echo "                                        "
echo -e " $purple       |   [7]facebook             [8]Encrypt    |"
echo -e " $green          --------------------------------------"
echo -e "                     $red [$cyan"$cyan"7777$red]Dump area"

echo -e " $red "
echo -e " [00] Exit           $green                          [99] update"
#echo -e "$green"
echo -e "$cyan"
echo -e "|---{$yellow my ip$cyan }---| "
       curl ifconfig.me
echo -e "$blue"
ifconfig wlan0 | grep -o 192..........
#echo -e "$green "
